from .ReLUFunction import ReLU
from .SigmoidFunction import Sigmoid
from .TanhFunction import Tanh
from .SoftplusFunction import Softplus
from .GaussianFunction import Gaussian
from .ComboTable import Table
